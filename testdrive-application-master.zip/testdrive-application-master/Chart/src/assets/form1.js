var currentStep = 0;

function nextStep(n) {
  var steps = document.querySelectorAll('.step');

  if (currentStep + n >= 0 && currentStep + n < steps.length) {
    steps[currentStep].classList.remove('show');
    currentStep += n;
    steps[currentStep].classList.add('show');
  }
}

document.getElementById('multiStepForm').addEventListener('submit', function(event) {
  event.preventDefault();
  alert('Form submitted!');
});


function togglePassword() {
  var passwordInput = document.getElementById('password');
  var showButton = document.querySelector('.show');
  if (passwordInput.type === 'password') {
    passwordInput.type = 'text';
    showButton.textContent = 'HIDE';
  } else {
    passwordInput.type = 'password';
    showButton.textContent = 'SHOW';
  }
}

function validateForm() {
  var zId = document.getElementById('zid').value;
  var username = document.getElementById('Name').value;
  var password = document.getElementById('password').value;
  var retypePassword = document.getElementById('retypePassword').value;

  // Define regular expressions for validation
  var usernameRegex = /^[a-zA-Z0-9!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]{6,20}$/;
  var zIdRegex = /^[a-zA-Z0-9]+$/;
  var passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

  // Perform validation
  if (!usernameRegex.test(username)) {
    alert("Username must be 6-20 characters long, containing only letters, numbers, and specific special characters");
    return;
  }

  if (!emailRegex.test(email)) {
    alert("Invalid email format");
    return;
  }

  if (!zIdRegex.test(zId)) {
    alert("Z ID should only contain alphanumeric characters, including 'z', and must not contain any spaces or special characters.");
    return;
  }

 

  

  if (!passwordRegex.test(password)) {
    alert("Invalid password. It must contain at least 8 characters, including one uppercase letter, one lowercase letter, one number, and one special character.");
    return;
  }

  if (password !== retypePassword) {
    alert("Re-password do not match with password");
    return;
  }

  // If all validations pass, you can submit the form or perform other actions
  alert("Registration successful!");
}


function openNav() {

  document.getElementById("mySidenav").style.width = "250px";

}

 

function closeNav() {

  document.getElementById("mySidenav").style.width = "0";

}