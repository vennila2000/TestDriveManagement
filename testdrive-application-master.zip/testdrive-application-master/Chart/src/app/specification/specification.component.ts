import { Component, OnInit } from '@angular/core';
import { ServService } from '../serv.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-specification',
  templateUrl: './specification.component.html',
  styleUrls: ['./specification.component.css']
})
export class SpecificationComponent {
  id:any;
  data:any;
  choice:any;
  constructor(private s : ServService,private r:ActivatedRoute,private v:Router){
    
    this.id = this.r.snapshot.paramMap.get('carId');
      this.s.getcarid(this.id,this.s.getToken()).subscribe(res=> this.data = res)
  }
  shedule(){
    console.log("hello")
    this.v.navigate(['sheduling',this.id]);
  }
  feedback(id:any){

  }

  }
