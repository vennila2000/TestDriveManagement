import { Component, OnInit, ViewChild } from '@angular/core';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';
import {MatSort, MatSortModule} from '@angular/material/sort';
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import { ServService } from '../serv.service';

@Component({
  selector: 'app-carmanagement',
  templateUrl: './carmanagement.component.html',
  styleUrls: ['./carmanagement.component.css']
})
export class CarmanagementComponent  implements OnInit{
  displayedColumns: string[] = ['carid', 'carName', 'model','fuelType',
    'maxPower' , 'maxTorque' , 'mileage' , 'transmission' , 'seatingCapacity' ,
    'bootSpace' , 'slotTime' , 'Action'];
  dataSource!: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  view:any;
  constructor(private ser:ServService) {}
 
  ngOnInit(): void {
    this.ser.getCars(this.ser.getToken()).subscribe((result) => {
    this.view = result;
    console.log(this.view)
    
    }); 
  }

  
  editCar(item:any){

  }
}
