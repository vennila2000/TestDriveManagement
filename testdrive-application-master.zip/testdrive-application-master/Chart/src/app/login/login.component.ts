import { Component } from '@angular/core';
import { ServService } from '../serv.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  constructor(private p:ServService,private c:Router) {}
  view:any;
  token:any;
  user:any;
  errormsg:any;
  logins(data:any){
  
        this.p.login(data).subscribe((res) => {this.view = res;
          this.token = this.view.AccessToken;
          this.user = this.view.User;
          console.log(this.view);
          this.p.setUser(this.user);
          this.p.setToken(this.token);
          this.p.setLogin(this.view.loginTime);
          
  
         if(this.user.department == "ISIT"){this.c.navigate(['getcardetails',this.user.empid]);}
         else if(this.user.department == "Manfacturer") {this.c.navigate(['manufacturerhome',this.user.empid]);}},
         (error)=>{
          this.errormsg = error.error;
         });
        
      
       

  }
}
