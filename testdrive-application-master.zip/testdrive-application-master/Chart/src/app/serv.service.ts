import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServService {

  constructor(private p:HttpClient) { }
  loginurl = "http://localhost:8090/api/v2";
  logins = "http://localhost:8090/api/v2/tdm/login";
  manufacture="http://localhost:8090/api/v2/tdm";
  tdm = "http://localhost:8090/tdm";

  getcarid(id:any,token:any){
    const headers = new HttpHeaders({
      "Authorization" : token
    })
    return this.p.get(this.manufacture+"/getcar/"+id,{headers})
  }
  postFeedback(data:any,token:any){
    const headers = new HttpHeaders({
      "Authorization" : token
    })
    return this.p.post(this.manufacture + "/feedback",data,{headers});
  }
  login(data:any){
    return this.p.post(this.logins,data);
  }
  addcarPost(data:any,token:any){
    const headers = new HttpHeaders({
      "Authorization" : token
    })
    return this.p.post(this.manufacture+"/add",data,{headers});
  }
  //car
  getCars(token:any){
    const headers = new HttpHeaders({
      "Authorization" : token
    })
    return this.p.get(this.manufacture+"/getallcar",{ headers });
  }
  postshedule(data:any,token:any){
    const headers = new HttpHeaders({
      "Authorization" : token
    })
    return  this.p.post(this.manufacture+"/testdriveregisteration",data,{headers});
  }
  getshedule(id:any){
    return this.p.get(this.manufacture+"/testdriveregisteration/"+id);
  }

  getFeedback(zid:any){
    return this.p.get(this.manufacture + "/getfeedback/"+zid);
  }

  getFeedbackAll(token:any){
    const headers = new HttpHeaders({
      "Authorization" : token
    })
    return this.p.get(this.manufacture + "/getallfeedback",{headers});
  }

  getFeedbackByCar(id:any,token:any){
    const headers = new HttpHeaders({
      "Authorization" : token
    })
    return this.p.get(this.manufacture+"/getfeedback/"+id,{headers});
  }

  user:any;
  setUser(data:any){
    this.user = data;
  }
  getUser(){
    return this.user;
  }
  token:any;
  setToken(token:any){
    this.token = token;
  }
  getToken(){
    return this.token;
  }
  getParticipant(token:any){
    const headers = new HttpHeaders({
      "Authorization" : token
    })
    return this.p.get(this.manufacture + "/getallparticipant",{headers});
  }
  getSchedulingByZid(zid:any,token:any){
    
    const headers = new HttpHeaders({
      "Authorization" : token
    })
    return this.p.get(this.manufacture+"/testdriveregisteration/"+zid,{headers})
  }
  makeTrue(id:any , data:any , token:any){
    const headers = new HttpHeaders({
      "Authorization" : token
    })
    return this.p.put(this.manufacture+"/verified/"+id,data,{headers});
  }
  schedule:any;
  setSchedule(data:any){
    this.schedule = data;
  }
  getSchedule(){
    return this.schedule;
  }
  getFeedbackManufacturer(){
    return 
  }

  verifyZid(zid:any){
    return this.p.post(this.manufacture+"/forgetpassword",zid);
  }

  verifyOTP(data:any){
    return this.p.post(this.manufacture+"/verification",data);
  }

  requestWithOtp(data:any){
    return this.p.post(this.manufacture+"/otpregisteration",data);
  }

  registerWithOtp(data:any){
    return this.p.post(this.manufacture+"/verification",data);
  }

  verifyForgotPassword(data:any){
    return this.p.post(this.manufacture+"/otpverification",data);
  }

  registeration(data:any){
    return this.p.post(this.manufacture+"/register",data);
  }
  loginTime:any;
  setLogin(data:any){
    this.loginTime = data;
  }

  getLogin(){
    return this.loginTime;
  }

  getAverageFeedbackByCar(id:any,token:any){
    const headers = new HttpHeaders({
      "Authorization" : token
    })
    return this.p.get(this.manufacture+"/getcaravgfeedback/"+id,{headers});
  }

  logoutObj:any = {};
  logout()
  {
    this.logoutObj.zid = this.getUser().zid;
    this.logoutObj.login = this.getLogin();
    this.setToken(null);
    this.setUser(null);
    this.setLogin(null);
    return this.p.post(this.manufacture+"/logout",this.logoutObj);
    
  }

  forgotPassword(data:any){
    return this.p.post(this.manufacture+"/changepassword",data);
  }

  carComparsionGet(car1:any){
    return this.p.get(this.manufacture+"/carsconnect/"+car1);
  }

  apikey = "F18rtfzw2wZUKsNLfEl+Ig==g3E8nm4hAXwnoJSl";

  getCarsFromApi(carname:any){

    const headers = new HttpHeaders({

      "X-Api-Key" : this.apikey 

    });

    return this.p.get("https://api.api-ninjas.com/v1/cars?limit=2&model="+carname,{headers});

  }

  getCarRegisteration(token:any,carid:any){
    const headers = new HttpHeaders({
      "Authorization" : token
    })
    return this.p.get(this.manufacture + "/testdriveregisterationcar/"+carid,{headers});
  }

}
