import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarfeedbackComponent } from './carfeedback.component';

describe('CarfeedbackComponent', () => {
  let component: CarfeedbackComponent;
  let fixture: ComponentFixture<CarfeedbackComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CarfeedbackComponent]
    });
    fixture = TestBed.createComponent(CarfeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
