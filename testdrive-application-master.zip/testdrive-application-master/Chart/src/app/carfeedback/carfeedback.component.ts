import { Component } from '@angular/core';
import { ServService } from '../serv.service';
import { ActivatedRoute } from '@angular/router';
import { Feedback } from '../feedback';

@Component({
  selector: 'app-carfeedback',
  templateUrl: './carfeedback.component.html',
  styleUrls: ['./carfeedback.component.css']
})
export class CarfeedbackComponent {
  id:any;
  value:any;
  feedback:Feedback = new Feedback()
  constructor(private s:ServService,private r:ActivatedRoute){
     this.id = this.r.snapshot.paramMap.get('carId');
    this.s.getFeedbackByCar(this.id,this.s.getToken()).subscribe((res:any)=>this.value=res)
    
    
  }
}
