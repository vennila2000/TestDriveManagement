import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServService } from '../serv.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  id:any;
  name:any;
  dept:any;
  constructor(private r:Router,private s:ServService,private v:ActivatedRoute){
    this.id = this.v.snapshot.paramMap.get('empid');
    this.name = this.s.getUser().name;
    this.dept = this.s.getUser().department;
  }
  logouts(){
    this.s.logout().subscribe(res => {console.log("logged out")});
    
     this.r.navigate([''])
    }
    
    feedback(){
      this.r.navigate(['listoffeedback',this.id])
    }
   
}

