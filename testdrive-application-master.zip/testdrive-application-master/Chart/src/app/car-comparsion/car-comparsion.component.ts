import { Component } from '@angular/core';
import { ServService } from '../serv.service';

@Component({
  selector: 'app-car-comparsion',
  templateUrl: './car-comparsion.component.html',
  styleUrls: ['./car-comparsion.component.css']
})
export class CarComparsionComponent {
value1:any;
value2:any;
car1:any;
car2:any;
cars:any =[];
cars1:any=[];
car:any ={};
showComparisonTable = false;


  constructor(private p:ServService){

  }

  onSubmit(data:any){
this.car1=data.car1;
this.car2=data.car2;


 
  this.p.getCarsFromApi(this.car1).subscribe((res:any)=>{this.cars1 = res;})
  this.p.carComparsionGet(this.car2).subscribe((res:any)=>{this.cars = res;})
  
  
  
    
  }
  com(){
    this.showComparisonTable = true;
  }
  
}

