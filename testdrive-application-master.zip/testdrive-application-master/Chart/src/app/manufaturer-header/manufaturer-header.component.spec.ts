import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManufaturerHeaderComponent } from './manufaturer-header.component';

describe('ManufaturerHeaderComponent', () => {
  let component: ManufaturerHeaderComponent;
  let fixture: ComponentFixture<ManufaturerHeaderComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ManufaturerHeaderComponent]
    });
    fixture = TestBed.createComponent(ManufaturerHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
