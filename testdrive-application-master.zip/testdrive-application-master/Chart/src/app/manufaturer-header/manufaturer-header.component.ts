import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServService } from '../serv.service';

@Component({
  selector: 'app-manufaturer-header',
  templateUrl: './manufaturer-header.component.html',
  styleUrls: ['./manufaturer-header.component.css']
})
export class ManufaturerHeaderComponent {
  id:any;
  name:any;
  dept:any;
  constructor(private r:Router,private s:ServService,private v:ActivatedRoute){
    this.id = this.v.snapshot.paramMap.get('empid');
    this.name = this.s.getUser().name;
    this.dept = this.s.getUser().department;
 
  }
  logouts(){
    this.s.logout().subscribe(res => {console.log("logged out")});
    
     this.r.navigate([''])
    }
    newcar(){
      this.r.navigate(['caradd',this.id])
    }
    ver(){
      this.r.navigate(['manufacturerverifycard']);
    }
    pie(){
      this.r.navigate(['pie']);
    }
    carmanage(){
      this.r.navigate(['carmanagement'])
    }

    feedback(){
      this.r.navigate(['manufacturerchart']);
    }

    

     openNav(): void {
      const mySidenav = document.getElementById("mySidenav") as HTMLElement;
      if (mySidenav) {
        mySidenav.style.width = "200px";
      }
    }
    closeNav(): void {
      const mySidenav = document.getElementById("mySidenav") as HTMLElement;
      if (mySidenav) {
        mySidenav.style.width = "0";
      }
    }

    
}
