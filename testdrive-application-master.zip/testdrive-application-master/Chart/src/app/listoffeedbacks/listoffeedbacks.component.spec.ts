import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListoffeedbacksComponent } from './listoffeedbacks.component';

describe('ListoffeedbacksComponent', () => {
  let component: ListoffeedbacksComponent;
  let fixture: ComponentFixture<ListoffeedbacksComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ListoffeedbacksComponent]
    });
    fixture = TestBed.createComponent(ListoffeedbacksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
