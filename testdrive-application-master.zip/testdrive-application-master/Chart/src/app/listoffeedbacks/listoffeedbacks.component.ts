import { Component } from '@angular/core';
import { ServService } from '../serv.service';
import { Feedback } from '../feedback';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-listoffeedbacks',
  templateUrl: './listoffeedbacks.component.html',
  styleUrls: ['./listoffeedbacks.component.css']
})
export class ListoffeedbacksComponent {
  view:any;
  carid:any;
  carId:any;
  feedback:Feedback = new Feedback();
  constructor(private s:ServService,private r:Router){
    
    console.log(this.s.getUser().zid)
    console.log("list of feedback")
    this.s.getSchedulingByZid(this.s.getUser().zid,this.s.getToken()).subscribe(res =>{this.view = res});
    
    
  }
  
  feed(id:any){
      this.r.navigate(['feedback',id]);
  }
}
