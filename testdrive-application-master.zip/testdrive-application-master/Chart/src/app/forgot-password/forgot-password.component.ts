import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ServService } from '../serv.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent {
  zid:any;
  otp:any;
  currentStep = 1;
  formData: any = {}; // Object to store form data
  obj:any={}
  value:any={}
  

  prevStep() {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }




  
  constructor(private formBuilder:FormBuilder,private http:HttpClient,private s:ServService,private a:Router){}
  changePassword:any={};
  submitForm() {

    console.log(this.signupForm2.value); 
    if(this.signupForm2.value.password == this.signupForm2.value.retypePassword){
      this.changePassword.zid = this.zid;
     
      
      this.changePassword.newPassword = this.signupForm2.value.password;
      this.changePassword.confirmPassword = this.signupForm2.value.retypePassword;

      this.s.forgotPassword(this.changePassword).subscribe((res) => {console.log(res);
        this.a.navigate(['login']);});
    }
    else{
      console.log("Unable to register")
    }
    
  }

  public  signupForm2!: FormGroup;

  ngOnInit():void{
    this.signupForm2=this.formBuilder.group({
      // zid:[''],
    
      password:[''],
      retypePassword:['']
      // OTP:['']

     })

  }

  nextStep() {
    if (this.currentStep < 4) {
      
      
      this.obj.zid = this.zid;
      
      console.log(this.obj)
      this.s.verifyZid(this.obj).subscribe(res => {
        if(res == true){
          this.currentStep = 2;
        }
      });
    }
  }

  second(){
    this.value.zid = this.zid;
    this.value.otp = this.otp;
    console.log(this.value)
    this.s.verifyForgotPassword(this.value).subscribe(res =>{
      if(res == true){
        this.currentStep = 3;
      }
    });
  
  }
}
