import { Component, OnInit } from '@angular/core';
import { ServService } from '../serv.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manufacturer-chart',
  templateUrl: './manufacturer-chart.component.html',
  styleUrls: ['./manufacturer-chart.component.css']
})
export class ManufacturerChartComponent {
  data:any;
  value:any;
  id:any;
constructor(private s:ServService,private r:Router){
  this.s.getCars(this.s.getToken()).subscribe(res => this.data = res);
  // this.s.getFeedbackAll(this.s.getToken()).subscribe(res=> { this.data = res });
  

  
  // this.s.getcarid(this.data.id , this.s.getToken()).subscribe(res => console.log(res))
console.log(this.data);

//  this.s.getcarid(this.data.carId).subscribe(result=>console.log(result))
}
  getFeedback(item:any){
    
  } 
  chart(carId:any){
    this.r.navigate(['pie',carId]);
  }

  feedback(carId:any){
    this.r.navigate(['carfeedback',carId])
  }
}
