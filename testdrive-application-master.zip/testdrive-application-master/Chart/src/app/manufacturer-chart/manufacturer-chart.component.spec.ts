import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManufacturerChartComponent } from './manufacturer-chart.component';

describe('ManufacturerChartComponent', () => {
  let component: ManufacturerChartComponent;
  let fixture: ComponentFixture<ManufacturerChartComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ManufacturerChartComponent]
    });
    fixture = TestBed.createComponent(ManufacturerChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
