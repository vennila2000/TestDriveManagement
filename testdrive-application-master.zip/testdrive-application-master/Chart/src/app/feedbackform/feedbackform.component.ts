import { Component, OnInit } from '@angular/core';
import {FormBuilder, Validators, FormsModule, ReactiveFormsModule} from '@angular/forms';
import { ServService } from '../serv.service';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-feedbackform',
  templateUrl: './feedbackform.component.html',
  styleUrls: ['./feedbackform.component.css']
})
export class FeedbackformComponent {
 carName="";
 breaking_system:any;
 interior:any;
 engine:any;
 safety:any;
 comfort:any;
 storage:any;
 lighting:any;
 comment:any;
 carname:any;
 id:any;
 data:any;
  user:any;
cname:any;
 constructor(private r:ActivatedRoute,private s:ServService,private t:Router){
  if(this.s.getUser()){
    this.user = this.s.getUser();
    // this.s.setUser(null);
  }
  else{
    this.t.navigate(['login']);
  }

  this.id = this.r.snapshot.paramMap.get('carId');
    this.s.getcarid(this.id,this.s.getToken()).subscribe(res=>this.data=res)
    
    console.log(this.data);

}

vek(data:any){
  console.log(data);
  let obj = data;
  obj.zid = this.s.getUser().zid;
  obj.carid = this.id;
  obj.carName = this.data.carName;
  console.log(obj);
  return this.s.postFeedback(obj,this.s.getToken()).subscribe();
  
}
}

  


