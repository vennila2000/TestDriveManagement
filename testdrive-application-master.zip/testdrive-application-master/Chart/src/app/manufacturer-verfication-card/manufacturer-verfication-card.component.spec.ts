import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManufacturerVerficationCardComponent } from './manufacturer-verfication-card.component';

describe('ManufacturerVerficationCardComponent', () => {
  let component: ManufacturerVerficationCardComponent;
  let fixture: ComponentFixture<ManufacturerVerficationCardComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ManufacturerVerficationCardComponent]
    });
    fixture = TestBed.createComponent(ManufacturerVerficationCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
