import { Component } from '@angular/core';
import { ServService } from '../serv.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manufacturer-verfication-card',
  templateUrl: './manufacturer-verfication-card.component.html',
  styleUrls: ['./manufacturer-verfication-card.component.css']
})
export class ManufacturerVerficationCardComponent {
  data:any;
  user:any;
  value:any;
  id:any;
constructor(private s:ServService,private r:Router){
  if(this.s.getUser()){
    this.user = this.s.getUser();
    // this.s.setUser(null);
  }
  else{
    this.r.navigate(['login']);
  }
  this.s.getCars(this.s.getToken()).subscribe(res =>this.data=res);
  
}
verify(carId:any){
  this.r.navigate(['participant',carId])
} 
}
