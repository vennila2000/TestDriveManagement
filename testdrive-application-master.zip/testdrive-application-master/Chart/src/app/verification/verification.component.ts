import { Component, OnInit } from '@angular/core';
import { ServService } from '../serv.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-verification',
  templateUrl: './verification.component.html',
  styleUrls: ['./verification.component.css']
})

export class VerificationComponent {
  user:any;
  cars:any;
  s:any;
  token:any;
  result:any;
  id:any;
    constructor(private p:ServService,private r:Router,private a:ActivatedRoute){
       this.id = this.a.snapshot.paramMap.get('carId');
       this.p.getCarRegisteration(this.p.getToken(),this.id).subscribe(res=>this.cars=res)

      //  this.p.getshedule(this.p.getUser().zid).subscribe(result=> this.s= result);
// this.token = this.p.getToken();

        // this.p.getParticipant(this.s.getToken()).subscribe(res => console.log(res));
    }
    
  // ngOnInit(): void {
  //   this.p.getParticipant(this.token).subscribe(res => {this.cars = res});
  // }
    choice:boolean = false;
    allow(data:any){
      if(!data.validation){
        let obj = data;
        obj.validation = true;
        console.log(obj);
        this.p.makeTrue(obj.regid,obj,this.p.getToken()).subscribe(res=>{console.log("success")});
      }
      
      
     }

}
