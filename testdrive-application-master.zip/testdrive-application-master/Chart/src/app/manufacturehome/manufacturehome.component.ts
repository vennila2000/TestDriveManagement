import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServService } from '../serv.service';

@Component({
  selector: 'app-manufacturehome',
  templateUrl: './manufacturehome.component.html',
  styleUrls: ['./manufacturehome.component.css']
})
export class ManufacturehomeComponent {
  id:any;
  constructor(private r:Router,private s:ServService,private v:ActivatedRoute){
    this.id = this.v.snapshot.paramMap.get('empid');
 
  }
  logout(){
    
    this.s.setUser(null);
    this.r.navigate(['login'])
    }
    newcar(){
      this.r.navigate(['caradd',this.id])
    }
}
