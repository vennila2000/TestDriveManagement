import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManufacturehomeComponent } from './manufacturehome.component';

describe('ManufacturehomeComponent', () => {
  let component: ManufacturehomeComponent;
  let fixture: ComponentFixture<ManufacturehomeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ManufacturehomeComponent]
    });
    fixture = TestBed.createComponent(ManufacturehomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
