import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetcardetailsComponent } from './getcardetails.component';

describe('GetcardetailsComponent', () => {
  let component: GetcardetailsComponent;
  let fixture: ComponentFixture<GetcardetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GetcardetailsComponent]
    });
    fixture = TestBed.createComponent(GetcardetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
