import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ServService } from '../serv.service';

@Component({
  selector: 'app-getcardetails',
  templateUrl: './getcardetails.component.html',
  styleUrls: ['./getcardetails.component.css']
})
export class GetcardetailsComponent {
  displayedCards:any;
  choice:boolean = true;
  user:any;
  constructor(private r:Router,private s:ServService){
    if(this.s.getUser()){
      this.user = this.s.getUser();
      // this.s.setUser(null);
    }
    else{
      this.r.navigate(['login']);
    }
    
    this.s.getCars(this.s.getToken()).subscribe(res => this.displayedCards = res);
    
    console.log(this.s.getSchedule());
  }
  

  // shedule(carId:any){
  //   console.log(carId);
  //   this.r.navigate(['sheduling',carId]);
  // }
  specification(carId:any){
    console.log(carId);
    this.r.navigate(['spec',carId]);
  }
  feed(carId:any){
    this.r.navigate(['feedback',carId]);
  }
  data:any;

logout(){
  this.s.setUser(null);
  this.r.navigate(['login'])

}
}
