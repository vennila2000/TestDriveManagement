import { Component } from '@angular/core';
import { ServService } from '../serv.service';

@Component({
  selector: 'app-piechart',
  templateUrl: './piechart.component.html',
  styleUrls: ['./piechart.component.css']
})
export class PiechartComponent {
  view:any;
  carid:any;
  fid:any;
  car_name!: String;
  breaking_system!: any;
  interior!: number;
  engine!: number;
  safety!: number;
  comfort!: number;
  storage!: number;
  lighting!: number;
  arr:any[] = [];

  public piedata?: Object[];
  public legendSettings?: Object;
  public centerLabel?: Object;
  public centerLabelData: any = [
   
];


  
}