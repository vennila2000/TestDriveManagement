import { Component ,OnInit} from '@angular/core';
import { ServService } from '../serv.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-centerpie',
  templateUrl: './centerpie.component.html',
  styleUrls: ['./centerpie.component.css']
})
export class CenterpieComponent implements OnInit {
  d!:any;
  carid:any;
  fid:any;
  car_name!: String;
  breaking_system!: any;
  interior!: number;
  engine!: number;
  safety!: number;
  comfort!: number;
  storage!: number;
  lighting!: number;
  id!:any;
  constructor(private p:ServService,private r:ActivatedRoute){

    this.id = this.r.snapshot.paramMap.get('carId');
    this.p.getAverageFeedbackByCar(this.id,this.p.getToken()).subscribe(res => {

      this.d = res;
      
     this.iterateObject();
    });
  }

  
 
  public piedata?: Object[];
  public legendSettings?: Object;
  public centerLabel?: Object;
  public centerLabelData: any = [
   
];

  ngOnInit(): void {
      this.legendSettings = {
          visible: false
      };
      this.centerLabel = {
          text: 'Move Cursor <br> To Know value',
          hoverTextFormat: '${point.x}  <br> ${point.y}%'
      }
     
  }
  
  count = 7;
  
  iterateObject() {     

    for (let key in this.d) {   
      if (this.d.hasOwnProperty(key)  ) { 
          if(key != "carid" && key != "fid"){

            const value = this.d[key];     
      this.centerLabelData.push({ x:`${key}` , y: `${value}` ,text: `${key}:${value} %` });
          }
          
      
        }   
         
      } }      
  }
    

