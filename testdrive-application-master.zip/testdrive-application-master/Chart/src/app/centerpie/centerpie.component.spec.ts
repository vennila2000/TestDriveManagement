import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CenterpieComponent } from './centerpie.component';

describe('CenterpieComponent', () => {
  let component: CenterpieComponent;
  let fixture: ComponentFixture<CenterpieComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CenterpieComponent]
    });
    fixture = TestBed.createComponent(CenterpieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
