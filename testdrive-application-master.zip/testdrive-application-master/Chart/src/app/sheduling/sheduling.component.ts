import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServService } from '../serv.service';

@Component({
  selector: 'app-sheduling',
  templateUrl: './sheduling.component.html',
  styleUrls: ['./sheduling.component.css']
})
export class ShedulingComponent {
  selectedLocation:any;
  id!: any;
  data:any;
  view:any;
  regid:number = 104;
  validation:boolean = false;
  zid:any;
  reguser:any = [];
choice:any;
buttonDisabled = false;
  constructor(private r:ActivatedRoute,private s:ServService,private p:Router){
    this.id = this.r.snapshot.paramMap.get('carId');
      this.s.getcarid(this.id,this.s.getToken()).subscribe(res=>{this.data = res})
      // this.s.getCars().subscribe((res)=>{this.view=res})
      this.zid = this.s.getUser().zid;
      console.log(this.data);
      
    // console.log(this.zid);
    
    
    
  }
  btn!:boolean;
reg(data:any){
  let obj = data;
  data.validation = this.validation;
  data.carid = this.id;
  data.carname = this.data.carName;
  data.zid = this.zid;
  console.log(obj);
 
  this.btn = true;
    
    return this.s.postshedule(obj,this.s.getToken()).subscribe((res)=>{ this.p.navigate(['getcardetails',this.s.getUser().empid]);
   
  },
    
    )
    
}

disable(){

}
}
