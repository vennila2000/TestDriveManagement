import { Component } from '@angular/core';
import { ServService } from '../serv.service';
import { Router } from '@angular/router';
import { FormBuilder ,FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-addcar',
  templateUrl: './addcar.component.html',
  styleUrls: ['./addcar.component.css']
})
export class AddcarComponent {
  user:any;
  currentStep = 1;
  formData: any = {};
  http: any;
  

  constructor(private s:ServService,private r:Router,private formBuilder:FormBuilder){
    if(this.s.getUser()){
      this.user = this.s.getUser();
      // this.s.setUser(null);
    }
    else{
      this.r.navigate(['login']);
    }
    console.log(this.s.getToken())
  }

  nextStep() {
    if (this.currentStep < 4) {
      this.currentStep++;
    }
  }

  prevStep() {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }
  
  submitForm() {
    
    const carForm = new FormData();

    carForm.append('carName', this.signupForm.value.carName);
    carForm.append('model', this.signupForm.value.model);
    carForm.append('engine', this.signupForm.value.engine);
    carForm.append('fuelType', this.signupForm.value.fuelType);
    carForm.append('maxPower', this.signupForm.value.maxPower);
    carForm.append('maxTorque', this.signupForm.value.maxTorque);
    carForm.append('mileage', this.signupForm.value.mileage);
    carForm.append('transmission', this.signupForm.value.transmission);
    carForm.append('seatingCapacity', this.signupForm.value.seatingCapacity);
    carForm.append('bootSpace', this.signupForm.value.bootSpace);
    carForm.append('date1', this.signupForm.value.date1);
    carForm.append('date2', this.signupForm.value.date2);
    carForm.append('date3', this.signupForm.value.date3);
    
    if (this.selectedFile) {

      carForm.append('file', this.selectedFile, this.selectedFile.name);
  
    }
    console.log(this.signupForm.value)
      this.s.addcarPost(carForm,this.s.getToken()).subscribe(
       res => console.log(res)

      );
  }
  

  public  signupForm!: FormGroup;

  ngOnInit():void{
    this.signupForm=this.formBuilder.group({
      carId:['', Validators.required],
      carName:['',[Validators.required, Validators.pattern(/^[A-Za-z]+$/)]],
      model:['',[Validators.required, Validators.pattern(/^[A-Za-z0-9]+$/)]],
      file:['', Validators.required],
      engine: ['', [Validators.required, Validators.pattern(/^[A-Za-z0-9]+$/)]],
      fuelType:['',[Validators.required, Validators.pattern(/^[A-Za-z]+$/)]],
      maxPower:['',[Validators.required, Validators.pattern(/@.*rpm.*\d/)]],
      maxTorque:['',[Validators.required, Validators.pattern(/@.*rpm.*\d/)]],
      mileage:['',[Validators.required, Validators.pattern(/^\d+ km\/l$/)]],
      transmission:['', [Validators.required, Validators.pattern(/^[0-9]+$/)]],
      seatingCapacity:['',[Validators.required, Validators.pattern(/^[0-9]+$/)]],
      bootSpace:['',[Validators.required, Validators.pattern(/^[0-9]+$/)]],
      date1:['',Validators.required],
      date2:['',Validators.required],
      date3:['',Validators.required],
    })

  }

  get carName(){
    return this.signupForm.get('carName');
  }
  get model(){
    return this.signupForm.get('model');
  }
  get file(){
    return this.signupForm.get('file');
  }
  get engine(){
    return this.signupForm.get('engine');
  }
  get fuelType(){
    return this.signupForm.get('fuelType');
  }
  get maxPower(){
    return this.signupForm.get('maxPower');
  }
  get maxTorque(){
    return this.signupForm.get('maxTorque');
  }
  get mileage(){
    return this.signupForm.get('mileage');
  }
  get transmission(){
    return this.signupForm.get('transmission');
  }
  
  get seatingCapacity(){
    return this.signupForm.get('seatingCapacity');
  }
  get bootSpace(){
    return this.signupForm.get('bootSpace');
  }
  get date1(){
    return this.signupForm.get('date1');
  }
  get date2(){
    return this.signupForm.get('date2');
  }
  get date3(){
    return this.signupForm.get('date3');
  }

  selectedFile!: File ;

  onFileChange(event:Event) {

    const inputElement = event.target as HTMLInputElement;

    if (inputElement.files && inputElement.files.length > 0) {

    this.selectedFile = inputElement.files[0];

  }}
}
