import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ChartModule } from '@syncfusion/ej2-angular-charts';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CharComponent } from './char/char.component';


import { GridModule } from '@syncfusion/ej2-angular-grids';
import { PageService, SortService, FilterService, GroupService  } from '@syncfusion/ej2-angular-grids';
import { AccumulationChartModule } from '@syncfusion/ej2-angular-charts';
import { PieSeriesService, AccumulationTooltipService, AccumulationDataLabelService } from '@syncfusion/ej2-angular-charts';
import { LineSeriesService, DateTimeService, DataLabelService,StackingColumnSeriesService,CategoryService, ChartShape,
       StepAreaSeriesService,SplineSeriesService, ChartAnnotationService, LegendService, TooltipService, StripLineService,
       SelectionService,ScatterSeriesService
    } from '@syncfusion/ej2-angular-charts';
import { CenterpieComponent } from './centerpie/centerpie.component';
   
  
import {HttpClientModule} from '@angular/common/http';


import { enableRipple } from '@syncfusion/ej2-base';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { FormsModule, ReactiveFormsModule } from '@angular/forms'; 

import { MatToolbarModule } from '@angular/material/toolbar';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatStepperModule} from '@angular/material/stepper';
import {MatButtonModule} from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule} from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import {MatPaginatorModule} from '@angular/material/paginator';
import { GetcardetailsComponent } from './getcardetails/getcardetails.component';
import { ShedulingComponent } from './sheduling/sheduling.component';
import { FeedbackformComponent } from './feedbackform/feedbackform.component';
enableRipple(true);
import { ButtonModule } from '@syncfusion/ej2-angular-buttons';
import { RatingModule } from '@syncfusion/ej2-angular-inputs';
import { NgxStarRatingModule } from 'ngx-star-rating';
import { LoginComponent } from './login/login.component';
import { AddcarComponent } from './addcar/addcar.component';
import { CarmanagementComponent } from './carmanagement/carmanagement.component';
import { PiechartComponent } from './piechart/piechart.component';
import { VerificationComponent } from './verification/verification.component';
import { SpecificationComponent } from './specification/specification.component';
import { ManufacturehomeComponent } from './manufacturehome/manufacturehome.component';
import { HeaderComponent } from './header/header.component';
import { ManufaturerHeaderComponent } from './manufaturer-header/manufaturer-header.component';
import { FooterComponent } from './footer/footer.component';
import { ListoffeedbacksComponent } from './listoffeedbacks/listoffeedbacks.component';
import { HighChartComponent } from './high-chart/high-chart.component';
import { ManufacturerChartComponent } from './manufacturer-chart/manufacturer-chart.component';
import { CarfeedbackComponent } from './carfeedback/carfeedback.component';
import { HomeComponent } from './home/home.component';
import { RegistrationComponent } from './registration/registration.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { CarComparsionComponent } from './car-comparsion/car-comparsion.component';
import { ManufacturerVerficationCardComponent } from './manufacturer-verfication-card/manufacturer-verfication-card.component';
@NgModule({
  declarations: [
    AppComponent,
    CharComponent,

    CenterpieComponent,
  
    
             GetcardetailsComponent,
             ShedulingComponent,
             FeedbackformComponent,
             LoginComponent,
             AddcarComponent,
             CarmanagementComponent,
             PiechartComponent,
             VerificationComponent,
             SpecificationComponent,
             ManufacturehomeComponent,
             HeaderComponent,
             ManufaturerHeaderComponent,
             FooterComponent,
             ListoffeedbacksComponent,
             HighChartComponent,
             ManufacturerChartComponent,
             CarfeedbackComponent,
             HomeComponent,
             RegistrationComponent,
             ForgotPasswordComponent,
             CarComparsionComponent,
             ManufacturerVerficationCardComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ChartModule,
    GridModule,
    AccumulationChartModule,
    HttpClientModule,
    MatPaginatorModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatStepperModule,
    MatToolbarModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatCardModule,
    RatingModule,
    ButtonModule,NgxStarRatingModule,MatIconModule,MatTableModule,MatSortModule
    
    
  ],
  providers: [
    LineSeriesService, DateTimeService, DataLabelService, StackingColumnSeriesService,CategoryService,
    StepAreaSeriesService, SplineSeriesService, ChartAnnotationService, LegendService, TooltipService, StripLineService,
    PieSeriesService, AccumulationTooltipService, AccumulationDataLabelService, SelectionService,ScatterSeriesService
    ,PageService,GroupService,SortService,FilterService,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
