export class Feedback {
    id!:number
    carid!:number
    zid!: String
    carName!: String
    breakingSystem!:number;
    interior!:number;
    engine!:number;
    safety !:number;
    comfort!:number;
    storage!:number;
    lighting!:number;
    comment!:String 
}

