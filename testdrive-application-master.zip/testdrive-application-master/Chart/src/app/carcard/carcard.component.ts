import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServService } from '../serv.service';

@Component({
  selector: 'app-carcard',
  templateUrl: './carcard.component.html',
  styleUrls: ['./carcard.component.css']
})
export class CarcardComponent {
  displayedCards:any;
  constructor(private r:Router,private s:ServService){
    this.s.getCars().subscribe(res => this.displayedCards = res);
    console.log(this.displayedCards)
  }


  shedule(id:any){
    console.log(id);
    this.r.navigate(['card',id]);
  }

 
showAll = false;

toggleCards() {
  this.showAll = !this.showAll;
}


}
