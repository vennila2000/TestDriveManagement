import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ServService } from '../serv.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {
  zid:any;
  otp:any;
  currentStep = 1;
  formData: any = {}; // Object to store form data
  obj:any={}
  value:any={}
  

  prevStep() {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }




  
  constructor(private formBuilder:FormBuilder,private http:HttpClient,private s:ServService,private a:Router){}
  registeration:any={};
  submitForm() {

    console.log(this.signupForm2.value); 
    if(this.signupForm2.value.password == this.signupForm2.value.retypePassword){
      this.registeration.zid = this.zid;
      this.registeration.name = this.signupForm2.value.Name;
      this.registeration.department = this.signupForm2.value.department;
      this.registeration.password = this.signupForm2.value.password;
      this.s.registeration(this.registeration).subscribe(res => {console.log(res);
        this.a.navigate(['login']);});
    }
    else{
      console.log("Unable to register")
    }
    
  }

  public  signupForm2!: FormGroup;

  ngOnInit():void{
    this.signupForm2=this.formBuilder.group({
      // zid:[''],
      Name:[''],
      department:[''],
      password:[''],
      retypePassword:['']
      // OTP:['']

     })

  }

  nextStep() {
    if (this.currentStep < 4) {
      
      
      this.obj.zid = this.zid;
      
      console.log(this.obj)
      this.s.requestWithOtp(this.obj).subscribe(res => {
        if(res == true){
          this.currentStep = 2;
        }
      });
    }
  }

  second(){
    this.value.zid = this.zid;
    this.value.otp = this.otp;
    console.log(this.value)
    this.s.registerWithOtp(this.value).subscribe(res =>{
      if(res == true){
        this.currentStep = 3;
      }
    });
  
  }


}
