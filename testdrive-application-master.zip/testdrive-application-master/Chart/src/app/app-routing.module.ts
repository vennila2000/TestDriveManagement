import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GetcardetailsComponent } from './getcardetails/getcardetails.component';
import { ShedulingComponent } from './sheduling/sheduling.component';
import { FeedbackformComponent } from './feedbackform/feedbackform.component';
import { CenterpieComponent } from './centerpie/centerpie.component';
import { LoginComponent } from './login/login.component';
import { AddcarComponent } from './addcar/addcar.component';
import { CarmanagementComponent } from './carmanagement/carmanagement.component';
import { PiechartComponent } from './piechart/piechart.component';
import { VerificationComponent } from './verification/verification.component';
import { SpecificationComponent } from './specification/specification.component';
import { ManufacturehomeComponent } from './manufacturehome/manufacturehome.component';
import { ListoffeedbacksComponent } from './listoffeedbacks/listoffeedbacks.component';
import { ManufacturerChartComponent } from './manufacturer-chart/manufacturer-chart.component';
import { CarfeedbackComponent } from './carfeedback/carfeedback.component';
import { HomeComponent } from './home/home.component';
import { RegistrationComponent } from './registration/registration.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { CarComparsionComponent } from './car-comparsion/car-comparsion.component';
import { ManufacturerVerficationCardComponent } from './manufacturer-verfication-card/manufacturer-verfication-card.component';

const routes: Routes = [

  {
    path:"getcardetails/:empid",
    component:GetcardetailsComponent
  },
  {
    path:"getcardetails",
    component:GetcardetailsComponent
  },
  {
    path:"sheduling/:carId",
    component:ShedulingComponent
  },
  {
    path:"feedback/:carId",
    component:FeedbackformComponent
  },
  {
    path:"pie/:carId",
    component:CenterpieComponent
  },
  {
    path:"login",
    component : LoginComponent
  },
  {
    path:"",
    component : HomeComponent

  },
    
  {
    path:"caradd/:empid",
    component:AddcarComponent
  },
  {
    path:"carmanagement",
    component:CarmanagementComponent
  },
  {
    path:"allfeedback",
    component:PiechartComponent
  },
  {
    path:"participant/:carId",
    component:VerificationComponent
  },
{
  path:"spec/:carId",
  component:SpecificationComponent
},
{
  path:"manufacturerhome/:empid",
  component:ManufacturehomeComponent
},
{
  path:"listoffeedback/:empid",
  component:ListoffeedbacksComponent
},
{
  path:"manufacturerchart",
  component:ManufacturerChartComponent
},
{
  path:"carfeedback/:carId",
  component:CarfeedbackComponent
},
{
  path:"reg",
  component:RegistrationComponent
},
{
  path:"forgotpassword",
  component:ForgotPasswordComponent
},
{
 path:"carsconnect",
 component:CarComparsionComponent 
},
{
  path:"manufacturerverifycard",
  component:ManufacturerVerficationCardComponent
},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
