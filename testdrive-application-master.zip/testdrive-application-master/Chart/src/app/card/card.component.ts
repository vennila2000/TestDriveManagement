import { Component, OnInit } from '@angular/core';
import { ServService } from '../serv.service';
import { ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {
  id!:number;
 
  constructor(private t:ServService,private rot:ActivatedRoute){
    this.rot.paramMap.subscribe((params:ParamMap)=>{
      this.id=parseInt(params.get('id') || '')
      console.log(this.id)
    })

}
  ngOnInit(): void {
   
  }
}

    // this.rot.queryParams.subscribe(params=>{
    //   this.id = +params['id'];
    //   console.log(this.id);
    
     
// })