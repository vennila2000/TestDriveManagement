package com.projecttdm.jwt.util;

import java.util.Date;

import org.springframework.stereotype.Component;

import com.projecttdm.entity.Registeration;
import com.projecttdm.jwt.common.AccessDeniedException;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;


@Component
public class JwtUtil {
	public static String key = "vasanth";
	public static long expiryDuration = 60*60;
	Date issuedAt = new Date();
	public String generateJwt(Registeration user) {
		String id = (user.getZid());
		String username = user.getName();
		Date issuedat = new Date();
		long millitime = System.currentTimeMillis();
		long milli = millitime + expiryDuration * 100000;
		Date future = new Date(milli);
		
		
		Claims claim = Jwts.claims()
				.setIssuer(id)
				.setIssuedAt(issuedat)
				.setExpiration(future);
		claim.put("username",user.getName());
		
		
		return Jwts.builder()
				.setClaims(claim)
				.signWith(SignatureAlgorithm.HS512, key)
				.compact();
	}
	
	public void verify(String authorization) throws Exception {
		
		try {
			Jwts.parser().setSigningKey(key).parseClaimsJws(authorization);
		}catch(Exception e) {
			throw new AccessDeniedException("UnAuthorized request Access Denied");
		}
	}
}
