package com.projecttdm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.projecttdm.entity.CarDetails;
import com.projecttdm.jwt.dto.LoginRequestZIddto;
import com.projecttdm.jwt.util.JwtUtil;
import com.projecttdm.service.ManufactureService;
import com.projecttdm.service.UserService;

@RestController
@RequestMapping("/tdm")
public class TDMController {
	@Autowired UserService userservice;
	@Autowired JwtUtil jwtutil;
	@Autowired ManufactureService manufactureservice;
	
//	@Autowired UserRegisterationService userregisterationservice;
//	
//	
//	@PostMapping("/register")
//	public ResponseEntity<?> registerUser(@RequestBody Registeration reg) {
//		return userregisterationservice.register(reg);
//		
//	}
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody LoginRequestZIddto loginzid) {
		return userservice.logins(loginzid);
	}
	
	@GetMapping("/getallcar")
	public ResponseEntity<?> getAllCar(@RequestHeader(value="Authorization") String auth) throws Exception{
		jwtutil.verify(auth);
		List<CarDetails> list = manufactureservice.getCar();
		return new ResponseEntity<List<CarDetails>>(list,HttpStatus.OK);
	}

}
