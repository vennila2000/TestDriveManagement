package com.projecttdm.jwt.dto;

public class LoginRequestZIddto {
	
	private String zid;
	private String password;
	public LoginRequestZIddto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LoginRequestZIddto(String zid, String password) {
		super();
		this.zid = zid;
		this.password = password;
	}
	public String getZid() {
		return zid;
	}
	public void setZid(String zid) {
		this.zid = zid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
