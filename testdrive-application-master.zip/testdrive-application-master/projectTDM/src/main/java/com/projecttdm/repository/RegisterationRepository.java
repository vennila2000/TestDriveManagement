package com.projecttdm.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.projecttdm.entity.Registeration;

public interface RegisterationRepository extends JpaRepository<Registeration,Integer>{
	Optional<Registeration> findByZid(String zid);
}
