package com.projecttdm.jwt.config;

import org.springframework.stereotype.Component;


@Component
public class JwtInterceptor {
	
	

}
