package com.projecttdm.entity;

import java.util.Arrays;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;

@Entity
public class CarDetails {
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private int carId;
	 private String carName;
	 private String model;
	 private String engine;
	 private String fuelType;
	 private String maxPower;
	 private String maxTorque;
	 private String mileage;
	 private String transmission;
	 private String seatingCapacity;
	 private String bootSpace;
	 private String date1;
	 private String date2;
	 private String date3;
	 private String picture;
	 @Lob
	 private byte[] image;
	public CarDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CarDetails(int carId, String carName, String model, String engine, String fuelType, String maxPower,
			String maxTorque, String mileage, String transmission, String seatingCapacity, String bootSpace,
			String date1, String date2, String date3,String picture, byte[] image) {
		super();
		this.carId = carId;
		this.carName = carName;
		this.model = model;
		this.engine = engine;
		this.fuelType = fuelType;
		this.maxPower = maxPower;
		this.maxTorque = maxTorque;
		this.mileage = mileage;
		this.transmission = transmission;
		this.seatingCapacity = seatingCapacity;
		this.bootSpace = bootSpace;
		this.date1 = date1;
		this.date2 = date2;
		this.date3 = date3;
		this.image = image;
		this.picture=picture;
	}
	public int getCarId() {
		return carId;
	}
	public void setCarId(int carId) {
		this.carId = carId;
	}
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getEngine() {
		return engine;
	}
	public void setEngine(String engine) {
		this.engine = engine;
	}
	public String getFuelType() {
		return fuelType;
	}
	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}
	public String getMaxPower() {
		return maxPower;
	}
	public void setMaxPower(String maxPower) {
		this.maxPower = maxPower;
	}
	public String getMaxTorque() {
		return maxTorque;
	}
	public void setMaxTorque(String maxTorque) {
		this.maxTorque = maxTorque;
	}
	public String getMileage() {
		return mileage;
	}
	public void setMileage(String mileage) {
		this.mileage = mileage;
	}
	public String getTransmission() {
		return transmission;
	}
	public void setTransmission(String transmission) {
		this.transmission = transmission;
	}
	public String getSeatingCapacity() {
		return seatingCapacity;
	}
	public void setSeatingCapacity(String seatingCapacity) {
		this.seatingCapacity = seatingCapacity;
	}
	public String getBootSpace() {
		return bootSpace;
	}
	public void setBootSpace(String bootSpace) {
		this.bootSpace = bootSpace;
	}
	public String getDate1() {
		return date1;
	}
	public void setDate1(String date1) {
		this.date1 = date1;
	}
	public String getDate2() {
		return date2;
	}
	public void setDate2(String date2) {
		this.date2 = date2;
	}
	public String getDate3() {
		return date3;
	}
	public void setDate3(String date3) {
		this.date3 = date3;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public String getPicture() {
		return picture;
	}
	
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	
}
