package com.projecttdm.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.projecttdm.entity.User;
import com.projecttdm.jwt.dto.LoginRequestdto;
import com.projecttdm.jwt.dto.UserRequestdto;
import com.projecttdm.jwt.util.JwtUtil;
import com.projecttdm.service.UserService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired UserService userservice;
	@Autowired JwtUtil jwtutil;
//	@PostMapping()
//	public String welcomeController(@RequestBody UserRequestdto userdto) {
//		
//		return "success";
//	}
	
	@PostMapping("/signup")
	public String signup(@RequestBody UserRequestdto userdto) {
		return userservice.login(userdto);
	}
	
//	@PostMapping("/login")
//	public ResponseEntity<?> login(@RequestBody LoginRequestdto logindto) {
//		return userservice.logins(logindto);
//	}
	
	@GetMapping("/data")
	public ResponseEntity<?> privatedata(@RequestHeader(value="Authorization") String auth) throws Exception {
		jwtutil.verify(auth);
		return new ResponseEntity<String>("this private data",HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/obj")
	public ResponseEntity<?> obj(@RequestHeader(value="Authorization") String auth) throws Exception {
		jwtutil.verify(auth);
		User u = new User();
		u.setEmail("vasanth@gmail.com");
		u.setUsername("vasanthcse");
		return new ResponseEntity<User>(u,HttpStatus.ACCEPTED);
	}
	
	
}
