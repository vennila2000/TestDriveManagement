package com.projecttdm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.projecttdm.entity.CarDetails;
import com.projecttdm.entity.OfficalDatabase;
import com.projecttdm.repository.CarDetailsRepository;
import com.projecttdm.repository.OfficalDatabaseRepository;
import com.projecttdm.repository.TDRegisterationRepository;


@Service
public class TDRegisteration implements TDRegisterationService{
	
	@Autowired CarDetailsRepository cardetailsrepository;
	@Autowired TDRegisterationRepository tdregisterationrepository;
	@Autowired OfficalDatabaseRepository officaldatabaserepository;
	@Autowired MailSenderService mailsenderservice;
	@Override
	public ResponseEntity<?> testdriverregisteration(com.projecttdm.entity.TDRegisteration tdregisteration) {
//		if(!cardetailsrepository.existsById(tdregisteration.getCarid())) {
//			return new ResponseEntity<String>("car id invalid",HttpStatus.BAD_REQUEST);
//		}
		
			tdregisterationrepository.save(tdregisteration);
			Optional<OfficalDatabase> zid = officaldatabaserepository.findByZid(tdregisteration.getZid());
			String email = zid.get().getEmail();
			String subject = "TestDrive Registeration";
			String text = "Your TestDrive Location in "+tdregisteration.getLocation()+"  your timeslot is "+tdregisteration.getSlottime()+"  Don't Forget to Join in the event Thank You"; 
			mailsenderservice.sendMail(email, subject, text);
			return new ResponseEntity<String>("Successfully Registered",HttpStatus.OK);
			
		}
		
	
	@Override
	public List<com.projecttdm.entity.TDRegisteration> getParticipant() {
		List<com.projecttdm.entity.TDRegisteration> allparticipant = tdregisterationrepository.findAll();
		return allparticipant;
	}
	@Override
	public ResponseEntity<?> getParticipantById(int carid) {
		if(cardetailsrepository.existsById(carid)) {
			Optional<com.projecttdm.entity.TDRegisteration> tdrbyid = Optional.of(tdregisterationrepository.findByCarid(carid).get());
			if(tdrbyid.isEmpty()) {
				return new ResponseEntity<String>("There is No participant for this car",HttpStatus.BAD_REQUEST);
			}
			else {
				return new ResponseEntity<Optional<com.projecttdm.entity.TDRegisteration>>(tdrbyid,HttpStatus.OK);
			}
		}
		else {
			return new ResponseEntity<String>("This car is not exist",HttpStatus.NOT_FOUND);
		}
	}
	
	public ResponseEntity<?> getParticipantByZid(String zid) {
		if(officaldatabaserepository.findByZid(zid).isPresent()) {
			if(tdregisterationrepository.findByZid(zid).isEmpty()) {
				return new ResponseEntity<String>("There is No participant in this zid",HttpStatus.BAD_REQUEST);
			}
			else {
				com.projecttdm.entity.TDRegisteration participantbyzid = tdregisterationrepository.findByZid(zid).get();
				return new ResponseEntity<com.projecttdm.entity.TDRegisteration>(participantbyzid,HttpStatus.OK);
			}
		}
		else {
			return new ResponseEntity<String>("This car is not exist",HttpStatus.NOT_FOUND);
		}
	}


	@Override
	public ResponseEntity<?> verify(int id, com.projecttdm.entity.TDRegisteration tdr) {
		com.projecttdm.entity.TDRegisteration td = tdregisterationrepository.findById(id).get();
		BeanUtils.copyProperties(tdr, td);
		tdregisterationrepository.save(td);
		return new ResponseEntity<String>("Successfully Allowed",HttpStatus.ACCEPTED);
	}


	@Override
	public ResponseEntity<?> getList(String zid) {
		
		List<com.projecttdm.entity.TDRegisteration> list = tdregisterationrepository.findByZid(zid);
		return new ResponseEntity<List<com.projecttdm.entity.TDRegisteration>>(list,HttpStatus.ACCEPTED);
	}


	
	
}
