package com.projecttdm.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.projecttdm.entity.TDRegisteration;

public interface TDRegisterationRepository extends JpaRepository<TDRegisteration,Integer>{
	Optional<TDRegisteration> findByCarid(int carid);
//	Optional<TDRegisteration> findByZid(String zid);
	List<TDRegisteration> findByZid(String zid);
}
