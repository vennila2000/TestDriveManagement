package com.projecttdm.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.projecttdm.entity.Registeration;

public interface UserRegisterationService {
	public ResponseEntity<?> register(Registeration reg);
}
