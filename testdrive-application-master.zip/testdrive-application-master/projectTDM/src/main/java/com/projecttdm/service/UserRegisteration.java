package com.projecttdm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.projecttdm.entity.Registeration;
import com.projecttdm.repository.RegisterationRepository;

public class UserRegisteration implements UserRegisterationService{

	@Autowired RegisterationRepository userrepo;
	@Override
	public ResponseEntity<?> register(Registeration reg) {
		if(!reg.getZid().startsWith("z")) {
			return new ResponseEntity<String>("zid must start with zid",HttpStatus.BAD_REQUEST);
		}
		else if(reg.getName().isEmpty()) {
			return new ResponseEntity<String>("Name cannot be empty",HttpStatus.BAD_REQUEST);
		}
		else if(!reg.getName().matches("^[a-zA-Z0-9 ]+$")) {
			return new ResponseEntity<String>("Name cannot have special character",HttpStatus.BAD_REQUEST);
		}
		else if(reg.getPassword().isEmpty()) {
			return new ResponseEntity<String>("password cannot be empty",HttpStatus.BAD_REQUEST);
		}
		else if(reg.getDepartment().isEmpty()) {
			return new ResponseEntity<String>("department cannot be empty",HttpStatus.BAD_REQUEST);
		}
		else {
			userrepo.save(reg);
			return new ResponseEntity<String>("Successfully Registered",HttpStatus.ACCEPTED);
		}

	}

	
}
