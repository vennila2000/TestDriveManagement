package com.projecttdm.jwt.common;

public class AccessDeniedException extends RuntimeException{
	public AccessDeniedException(String message){
		super(message);
	}
}
