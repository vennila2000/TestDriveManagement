package com.projecttdm.jwt.common;

import java.nio.file.AccessDeniedException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler
	public ResponseEntity handleAccessDeniedException(AccessDeniedException e) {
		return new ResponseEntity(HttpStatus.BAD_REQUEST);
	}
}
