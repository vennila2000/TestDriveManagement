package com.projecttdm.service;





import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.projecttdm.entity.OfficalDatabase;
import com.projecttdm.entity.Registeration;
import com.projecttdm.entity.User;
import com.projecttdm.jwt.dto.LoginRequestZIddto;
import com.projecttdm.jwt.dto.UserRequestdto;
import com.projecttdm.jwt.util.JwtUtil;
import com.projecttdm.repository.OfficalDatabaseRepository;
import com.projecttdm.repository.RegisterationRepository;
import com.projecttdm.repository.UserRepository;



@Service
public class UserService {

	@Autowired UserRepository userrepo;
	@Autowired JwtUtil jwtu;
	@Autowired OfficalDatabaseRepository officaldatabaserepo;
	@Autowired RegisterationRepository reg;
	
	public String login(UserRequestdto user) {
		 
		User u = new User();
		
		u.setUsername(user.getUsername());
		u.setPassword(user.getPassword());
		u.setEmail(user.getEmail());
		
		userrepo.save(u);
		return "success";
	}
	
	public ResponseEntity<?> logins(LoginRequestZIddto login) {
//		User user = userrepo.findOneByUsernameIgnoreCaseAndPassword(login.getUsername(),login.getPassword());
//		User users = userrepo.findByUsername(login.getUsername());
		Optional<OfficalDatabase> zid = officaldatabaserepo.findByZid(login.getZid()); 
		Optional<Registeration> registeration = reg.findByZid(login.getZid());
		Registeration reg = registeration.get();
		
		Map<String , Object> data = new HashMap<>();
		if(zid.isEmpty()) {
			return new ResponseEntity<String>("Invalid User",HttpStatus.BAD_REQUEST);
		}
		else if(!registeration.get().getPassword().matches(login.getPassword())) {
			
			return new ResponseEntity<String>("Incorrect Password",HttpStatus.BAD_REQUEST);
		}
		else {
			data.put("User", reg);
		}
		String token = jwtu.generateJwt(reg);
		
		data.put("AccessToken", token);
		return new ResponseEntity<Map<String,Object>>(data,HttpStatus.OK);
	}

}
