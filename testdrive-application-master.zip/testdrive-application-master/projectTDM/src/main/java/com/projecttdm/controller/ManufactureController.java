package com.projecttdm.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.projecttdm.entity.CarDetails;
import com.projecttdm.entity.Feedback;
import com.projecttdm.entity.OfficalDatabase;
import com.projecttdm.entity.TDRegisteration;
import com.projecttdm.jwt.dto.LoginRequestZIddto;
import com.projecttdm.jwt.util.JwtUtil;
import com.projecttdm.repository.CarDetailsRepository;
import com.projecttdm.repository.OfficalDatabaseRepository;
import com.projecttdm.service.CarDetailsService;
import com.projecttdm.service.FeedbackService;
import com.projecttdm.service.ImageServiceInterface;
import com.projecttdm.service.ManufactureService;
import com.projecttdm.service.TDRegisterationService;
import com.projecttdm.service.UserService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v2/tdm")
public class ManufactureController {
	
	@Autowired ManufactureService manufactureservice;
	@Autowired TDRegisterationService tdregisterationService;
	@Autowired OfficalDatabaseRepository onr;
	@Autowired FeedbackService feedbackservice;
	@Autowired ImageServiceInterface imageservice;
	@Autowired CarDetailsService cardetaislservice;
	@Autowired CarDetailsRepository carrepository;
	@Autowired JwtUtil jwtutil;
	@Autowired UserService userservice;
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody LoginRequestZIddto loginzid) {
		return userservice.logins(loginzid);
	}
	
	@PostMapping("/addnewcar")
	public ResponseEntity<?> addNewCar(@RequestBody CarDetails cardetails,@RequestHeader(value="Authorization") String auth)throws Exception{
		jwtutil.verify(auth);
		manufactureservice.addcar(cardetails);
		return new ResponseEntity<String>("Successfully Added",HttpStatus.OK);
	}
	
	@GetMapping("/getallcar")
	public ResponseEntity<?> getAllCar(@RequestHeader(value="Authorization") String auth) throws Exception{
		jwtutil.verify(auth); 
		return cardetaislservice.getAllCar();
	}
	
	@GetMapping("/getcar/{id}")
	public ResponseEntity<?> getcar(@PathVariable("id") int id,@RequestHeader(value="Authorization") String auth)throws Exception{
		jwtutil.verify(auth);
		return manufactureservice.getCarById(id);
	}
	
	@PostMapping("/testdriveregisteration")
	public ResponseEntity<?> testdriveregisteration(@RequestBody TDRegisteration tdregisteration,@RequestHeader(value="Authorization") String auth)throws Exception{
		jwtutil.verify(auth);
		return tdregisterationService.testdriverregisteration(tdregisteration);

	}
	
	@GetMapping("/testdriveregisteration/{zid}")
	public ResponseEntity<?> testdriveregisteration(@RequestHeader(value="Authorization") String auth,@PathVariable("zid") String zid)throws Exception{
		jwtutil.verify(auth);
		return tdregisterationService.getList(zid);

	}
	
	@PostMapping("/feedback")
	public ResponseEntity<?> feedback(@RequestBody Feedback feedbacks,@RequestHeader(value="Authorization") String auth)throws Exception{
		jwtutil.verify(auth);
		return feedbackservice.feedback(feedbacks);
	}
	
	@GetMapping("/getallfeedback")
	public ResponseEntity<?> getAllFeedback(@RequestHeader(value="Authorization") String auth)throws Exception{
		jwtutil.verify(auth);
		return feedbackservice.getFeedback();
	}
	
	@GetMapping("/getfeedback/{carid}")
	public ResponseEntity<?> getFeedbackByCarId(@PathVariable("carid") int carid,@RequestHeader(value="Authorization") String auth)throws Exception{
		jwtutil.verify(auth);
		return feedbackservice.getFeedbackById(carid);
	}
	
	@GetMapping("/getfeedback/zid/{zid}")
	public ResponseEntity<?> getFeedbackByZid(@PathVariable("zid") String zid,@RequestHeader(value="Authorization") String auth)throws Exception{
		jwtutil.verify(auth);
		return feedbackservice.getFeedbackByZid(zid);
	}
	
	@PostMapping("/upload")
	public ResponseEntity<?> imageUpload(@RequestParam("file") MultipartFile file,@RequestHeader(value="Authorization") String auth)throws Exception{
		jwtutil.verify(auth);
		return imageservice.uploadImage(file);
	}
	
	@GetMapping("/getallparticipant")
	public ResponseEntity<?> getParticipant(@RequestHeader(value="Authorization") String auth)throws Exception{
		jwtutil.verify(auth);
		List<TDRegisteration> list = tdregisterationService.getParticipant();
		return new ResponseEntity<List<TDRegisteration>>(list,HttpStatus.OK);
	}
	
//	@GetMapping("/getparticipantcar/{carid}")
//	public ResponseEntity<?> getParticipantyById(@PathVariable("carid") int carid,@RequestHeader(value="Authorization") String auth)throws Exception{
//		jwtutil.verify(auth);
//		return tdregisterationService.getParticipantById(carid);
//	}
	
	@GetMapping("/getparticipant/{zid}")
	public ResponseEntity<?> getParticipantByZid(@PathVariable("zid") String zid,@RequestHeader(value="Authorization") String auth)throws Exception{
		jwtutil.verify(auth);
		return tdregisterationService.getParticipantByZid(zid);
	}
	
//	@GetMapping("/getimage/{id}")
//	public ResponseEntity<?> getImageId(@PathVariable("id") Long id) {
//		return imageservice.getImage(id);
//	}
//	@GetMapping("image/{id}")
//    public ResponseEntity<byte[]> getImage(@PathVariable Long id) {
//        byte[] imageData = imageservice.getImageById(id);
//        return ResponseEntity.ok()
//                .contentType(MediaType.IMAGE_JPEG) // Adjust content type as needed
//                .body(imageData);
//    }
	
    @PostMapping("/add")
    public ResponseEntity<?> add(
    		@RequestParam("carName") String carName,
            @RequestParam("model") String model,
            @RequestParam("engine") String engine,
            @RequestParam("fuelType") String fuelType,
            @RequestParam("maxPower") String maxPower,
            @RequestParam("maxTorque") String maxTorque,
            @RequestParam("mileage") String mileage,
            @RequestParam("transmission") String transmission,
            @RequestParam("seatingCapacity") String seatingCapacity,
            @RequestParam("bootSpace") String bootSpace,
            @RequestParam("file") MultipartFile file,
            @RequestHeader(value="Authorization") String auth
            ) throws IOException,Exception{
    	jwtutil.verify(auth);  
    	CarDetails car = new CarDetails();
    	    car.setCarName(carName);
    	    car.setModel(model);
    	    car.setEngine(engine);
    	    car.setFuelType(fuelType);
    	    car.setMaxPower(maxPower);
    	    car.setMaxTorque(maxTorque);
    	    car.setMileage(mileage);
    	    car.setTransmission(transmission);
    	    car.setSeatingCapacity(seatingCapacity);
    	    car.setBootSpace(bootSpace);
    	    byte[] data = file.getBytes();
    	    car.setImage(data);
    	    return cardetaislservice.addNewCar(car);

    }
    
    @GetMapping("/get/{id}")
    public ResponseEntity<?>getd(@PathVariable("id") int id, @RequestHeader(value="Authorization") String auth)throws Exception{
    	jwtutil.verify(auth);
    	CarDetails car = carrepository.findById(id).get();
    	byte[] imageData = car.getImage();
        String base64Image = Base64.getEncoder().encodeToString(imageData);
        return new ResponseEntity<String>("data:image/png;base64," + base64Image, HttpStatus.ACCEPTED);
    	
    }
    
    
    @PutMapping("/verified/{id}")
	public ResponseEntity<?> verification(@PathVariable("id") int id ,@RequestBody TDRegisteration tdr, @RequestHeader(value="Authorization") String auth) throws Exception {
    	jwtutil.verify(auth);
    	return tdregisterationService.verify(id,tdr);
    	
    }
	
	
	
	@PostMapping("/addzid")
	public String addzid(@RequestBody OfficalDatabase ofd, @RequestHeader(value="Authorization") String auth)throws Exception {
		jwtutil.verify(auth);
		onr.save(ofd);
		return "successfully added";
	}
}
