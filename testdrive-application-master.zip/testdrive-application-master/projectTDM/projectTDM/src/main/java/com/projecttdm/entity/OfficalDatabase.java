package com.projecttdm.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class OfficalDatabase {
	@Id
	private int id;
	private String zid;
	private String email;
	public OfficalDatabase() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OfficalDatabase(int id, String zid, String email) {
		super();
		this.id = id;
		this.zid = zid;
		this.email = email;
	}
	@Override
	public String toString() {
		return "OfficalDatabase [id=" + id + ", zid=" + zid + ", email=" + email + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getZid() {
		return zid;
	}
	public void setZid(String zid) {
		this.zid = zid;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
