package com.projecttdm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.projecttdm.repository.CarDetailsRepository;
import com.projecttdm.repository.FeedbackRepository;
import com.projecttdm.repository.OfficalDatabaseRepository;
@Service
public class Feedback implements FeedbackService{
	
	@Autowired CarDetailsRepository cardetailsrepository;
	@Autowired OfficalDatabaseRepository officaldatabaserepository;
	@Autowired FeedbackRepository feedbackrepository;
	@Override
	public ResponseEntity<?> feedback(com.projecttdm.entity.Feedback feedbacks) {
		if(!cardetailsrepository.existsById(feedbacks.getCarid())) {
			return new ResponseEntity<String>("car id invalid",HttpStatus.BAD_REQUEST);
		}
		else if(officaldatabaserepository.findByZid(feedbacks.getZid()).isEmpty()) {
			return new ResponseEntity<String>("zid is invalid",HttpStatus.BAD_REQUEST);
		}
		else if(feedbacks.getBreakingSystem() == 0) {
			return new ResponseEntity<String>("BreakingSystem shouldn't be empty",HttpStatus.BAD_REQUEST);
		}
		else if(feedbacks.getBreakingSystem() >= 6) {
			return new ResponseEntity<String>("BreakingSystem shouldn't be more than 5 character",HttpStatus.BAD_REQUEST);
		}
		else if(feedbacks.getInterior() == 0) {
			return new ResponseEntity<String>("Interior shouldn't be empty",HttpStatus.BAD_REQUEST);
		}
		else if(feedbacks.getInterior() >= 6) {
			return new ResponseEntity<String>("Interior shouldn't be more than 5 character",HttpStatus.BAD_REQUEST);
		}
		else if(feedbacks.getEngine() == 0) {
			return new ResponseEntity<String>("Engine shouldn't be empty",HttpStatus.BAD_REQUEST);
		}
		else if(feedbacks.getEngine() >= 6) {
			return new ResponseEntity<String>("Engine shouldn't be more than 5 character",HttpStatus.BAD_REQUEST);
		}
		else if(feedbacks.getSafety() == 0) {
			return new ResponseEntity<String>("Safety shouldn't be empty",HttpStatus.BAD_REQUEST);
		}
		else if(feedbacks.getSafety() >= 6) {
			return new ResponseEntity<String>("Safety shouldn't be more than 5 character",HttpStatus.BAD_REQUEST);
		}
		else if(feedbacks.getComfort() == 0) {
			return new ResponseEntity<String>("Comfort shouldn't be empty",HttpStatus.BAD_REQUEST);
		}
		else if(feedbacks.getComfort() >= 6) {
			return new ResponseEntity<String>("Comfort shouldn't be more than 5 character",HttpStatus.BAD_REQUEST);
		}
		else if(feedbacks.getStorage() == 0) {
			return new ResponseEntity<String>("Storage shouldn't be empty",HttpStatus.BAD_REQUEST);
		}
		else if(feedbacks.getStorage() >= 6) {
			return new ResponseEntity<String>("Storage shouldn't be more than 5 character",HttpStatus.BAD_REQUEST);
		}
		else if(feedbacks.getLighting() == 0) {
			return new ResponseEntity<String>("Lighting shouldn't be empty",HttpStatus.BAD_REQUEST);
		}
		else if(feedbacks.getLighting() >= 6) {
			return new ResponseEntity<String>("Lighting shouldn't be more than 5 character",HttpStatus.BAD_REQUEST);
		}
		
		else {
			feedbackrepository.save(feedbacks);
			return new ResponseEntity<String>("Feedback successfully submitted",HttpStatus.OK);
		}
	}
	
	@Override
	public ResponseEntity<?> getFeedbackById(int carid) {
		if(!cardetailsrepository.existsById(carid)) {
			return new ResponseEntity<String>("car id invalid",HttpStatus.BAD_REQUEST);
		}
		else {
			Optional<com.projecttdm.entity.Feedback> feedback = feedbackrepository.findBycarid(carid);
			if(feedback.isEmpty()) {
				return new ResponseEntity<String>("No feedback for this carid",HttpStatus.BAD_REQUEST);
			}
			else if(feedback.isPresent()) {
				return new ResponseEntity<Optional<com.projecttdm.entity.Feedback>>(feedback,HttpStatus.OK);
			}
		}
		return new ResponseEntity<String>("invalid",HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getFeedback() {
		List<com.projecttdm.entity.Feedback> feedback = feedbackrepository.findAll();
		return new ResponseEntity<List<com.projecttdm.entity.Feedback>>(feedback,HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getFeedbackByZid(String zid) {
		if(officaldatabaserepository.findByZid(zid).isEmpty()) {
			return new ResponseEntity<String>("zid is invalid",HttpStatus.BAD_REQUEST);
		}
		else {
			Optional<com.projecttdm.entity.Feedback> feedback = feedbackrepository.findByZid(zid);
			if(feedback.isEmpty()) {
				return new ResponseEntity<String>("No feedback for this zid",HttpStatus.BAD_REQUEST);
			}
			else if(feedback.isPresent()) {
				return new ResponseEntity<Optional<com.projecttdm.entity.Feedback>>(feedback,HttpStatus.OK);
			}
		}
		return new ResponseEntity<String>("invalid",HttpStatus.BAD_REQUEST);
	}

	
	
	
	

}
