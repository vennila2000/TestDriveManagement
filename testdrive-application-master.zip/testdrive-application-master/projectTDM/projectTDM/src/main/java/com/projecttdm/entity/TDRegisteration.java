package com.projecttdm.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class TDRegisteration {
	@Id
	
	private int regid;
	private int carid;
	private String zid;
	private String carname;
	private String location;
	private String slottime;
	private Boolean validation;
	public TDRegisteration() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TDRegisteration(int regid, int carid, String zid, String carname, String location, String slottime,
			Boolean validation) {
		super();
		this.regid = regid;
		this.carid = carid;
		this.zid = zid;
		this.carname = carname;
		this.location = location;
		this.slottime = slottime;
		this.validation = validation;
	}
	@Override
	public String toString() {
		return "TDRegisteration [regid=" + regid + ", carid=" + carid + ", zid=" + zid + ", carname=" + carname
				+ ", location=" + location + ", slottime=" + slottime + ", validation=" + validation + "]";
	}
	public int getRegid() {
		return regid;
	}
	public void setRegid(int regid) {
		this.regid = regid;
	}
	public int getCarid() {
		return carid;
	}
	public void setCarid(int carid) {
		this.carid = carid;
	}
	public String getZid() {
		return zid;
	}
	public void setZid(String zid) {
		this.zid = zid;
	}
	public String getCarname() {
		return carname;
	}
	public void setCarname(String carname) {
		this.carname = carname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getSlottime() {
		return slottime;
	}
	public void setSlottime(String slottime) {
		this.slottime = slottime;
	}
	public Boolean getValidation() {
		return validation;
	}
	public void setValidation(Boolean validation) {
		this.validation = validation;
	}
	
	

}
