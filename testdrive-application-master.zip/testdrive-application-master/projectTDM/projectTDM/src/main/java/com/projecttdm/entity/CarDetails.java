package com.projecttdm.entity;

import java.util.Arrays;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;

@Entity
public class CarDetails {
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private int carId;
	 private String carName;
	 private String model;
	 private String engine;
	 private String fuelType;
	 private String maxPower;
	 private String maxTorque;
	 private String mileage;
	 private String transmission;
	 private String seatingCapacity;
	 private String bootSpace;
	 @Lob
	 private byte[] data;
	public CarDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CarDetails(int carId, String carName, String model, String engine, String fuelType, String maxPower,
			String maxTorque, String mileage, String transmission, String seatingCapacity, String bootSpace,
			byte[] data) {
		super();
		this.carId = carId;
		this.carName = carName;
		this.model = model;
		this.engine = engine;
		this.fuelType = fuelType;
		this.maxPower = maxPower;
		this.maxTorque = maxTorque;
		this.mileage = mileage;
		this.transmission = transmission;
		this.seatingCapacity = seatingCapacity;
		this.bootSpace = bootSpace;
		this.data = data;
	}
	@Override
	public String toString() {
		return "CarDetails [carId=" + carId + ", carName=" + carName + ", model=" + model + ", engine=" + engine
				+ ", fuelType=" + fuelType + ", maxPower=" + maxPower + ", maxTorque=" + maxTorque + ", mileage="
				+ mileage + ", transmission=" + transmission + ", seatingCapacity=" + seatingCapacity + ", bootSpace="
				+ bootSpace + ", data=" + Arrays.toString(data) + "]";
	}
	public int getCarId() {
		return carId;
	}
	public void setCarId(int carId) {
		this.carId = carId;
	}
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getEngine() {
		return engine;
	}
	public void setEngine(String engine) {
		this.engine = engine;
	}
	public String getFuelType() {
		return fuelType;
	}
	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}
	public String getMaxPower() {
		return maxPower;
	}
	public void setMaxPower(String maxPower) {
		this.maxPower = maxPower;
	}
	public String getMaxTorque() {
		return maxTorque;
	}
	public void setMaxTorque(String maxTorque) {
		this.maxTorque = maxTorque;
	}
	public String getMileage() {
		return mileage;
	}
	public void setMileage(String mileage) {
		this.mileage = mileage;
	}
	public String getTransmission() {
		return transmission;
	}
	public void setTransmission(String transmission) {
		this.transmission = transmission;
	}
	public String getSeatingCapacity() {
		return seatingCapacity;
	}
	public void setSeatingCapacity(String seatingCapacity) {
		this.seatingCapacity = seatingCapacity;
	}
	public String getBootSpace() {
		return bootSpace;
	}
	public void setBootSpace(String bootSpace) {
		this.bootSpace = bootSpace;
	}
	public byte[] getData() {
		return data;
	}
	public void setData(byte[] data) {
		this.data = data;
	}
	
	
	 
}
