package com.projecttdm.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.projecttdm.entity.Image;
import com.projecttdm.repository.ImageRepository;

@Service
public class ImageService implements ImageServiceInterface{
	@Autowired 
	private ImageRepository imageRepository;

    public Image saveImage(String fileName, byte[] data) {
    	
        Image image = new Image();
        image.setName(fileName);
        image.setData(data);
        
        return imageRepository.save(image);
    }

    public byte[] getImageById(Long id) {
        // Retrieve image data by ID from the repository
        Optional<Image> imageOptional = imageRepository.findById(id);
        
        if (imageOptional.isPresent()) {
            return imageOptional.get().getData();
        } else {
            throw new ImageNotFoundException("Image with ID " + id + " not found");
        }
    }

    public class ImageNotFoundException extends RuntimeException {
        public ImageNotFoundException(String message) {
            super(message);
        }
    }
    
    public ResponseEntity<?> uploadImage(MultipartFile file){
    	
    	 try {
             String fileName = file.getOriginalFilename();
             byte[] data = file.getBytes();
             saveImage(fileName, data);
             return new ResponseEntity<String>("Image uploaded successfully!",HttpStatus.OK);
         } catch (Exception e) {
             return new ResponseEntity<String>(e.getMessage(),HttpStatus.OK);
         }
    }
    
    public Image upload(MultipartFile file){
    	
   	 try {
            String fileName = file.getOriginalFilename();
            byte[] data = file.getBytes();
            return saveImage(fileName, data);
          
        } catch (Exception e) {
            return null;
        }
   }
    
    public ResponseEntity<?> getImage(Long id){
    	byte[] imageData = getImageById(id);
    	ByteArrayResource resource = new ByteArrayResource(imageData);

        return ResponseEntity.ok()
              .contentType(MediaType.IMAGE_JPEG) // Set the appropriate content type
              .contentLength(imageData.length)
              .body(resource);
    }

}
