package com.projecttdm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.projecttdm.entity.Image;

public interface ImageRepository extends JpaRepository<Image,Long>{

}
