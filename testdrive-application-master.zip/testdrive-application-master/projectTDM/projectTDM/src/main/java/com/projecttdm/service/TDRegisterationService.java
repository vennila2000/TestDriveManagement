package com.projecttdm.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.projecttdm.entity.TDRegisteration;

public interface TDRegisterationService {
	ResponseEntity<?> testdriverregisteration(TDRegisteration tdregisteration);
	public List<TDRegisteration> getParticipant();
	ResponseEntity<?> getParticipantById(int carid);
	ResponseEntity<?> getParticipantByZid(String zid);
}
