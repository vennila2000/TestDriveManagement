package com.projecttdm.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Feedback {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String zid;
	private int carid;
	private long breakingSystem;
	private long interior;
	private long engine;
	private long safety;
	private long comfort;
	private long storage;
	private long lighting;
	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Feedback(int id, String zid, int carid, long breakingSystem, long interior, long engine, long safety,
			long comfort, long storage, long lighting) {
		super();
		this.id = id;
		this.zid = zid;
		this.carid = carid;
		this.breakingSystem = breakingSystem;
		this.interior = interior;
		this.engine = engine;
		this.safety = safety;
		this.comfort = comfort;
		this.storage = storage;
		this.lighting = lighting;
	}
	@Override
	public String toString() {
		return "Feedback [id=" + id + ", zid=" + zid + ", carid=" + carid + ", breakingSystem=" + breakingSystem
				+ ", interior=" + interior + ", engine=" + engine + ", safety=" + safety + ", comfort=" + comfort
				+ ", storage=" + storage + ", lighting=" + lighting + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getZid() {
		return zid;
	}
	public void setZid(String zid) {
		this.zid = zid;
	}
	public int getCarid() {
		return carid;
	}
	public void setCarid(int carid) {
		this.carid = carid;
	}
	public long getBreakingSystem() {
		return breakingSystem;
	}
	public void setBreakingSystem(long breakingSystem) {
		this.breakingSystem = breakingSystem;
	}
	public long getInterior() {
		return interior;
	}
	public void setInterior(long interior) {
		this.interior = interior;
	}
	public long getEngine() {
		return engine;
	}
	public void setEngine(long engine) {
		this.engine = engine;
	}
	public long getSafety() {
		return safety;
	}
	public void setSafety(long safety) {
		this.safety = safety;
	}
	public long getComfort() {
		return comfort;
	}
	public void setComfort(long comfort) {
		this.comfort = comfort;
	}
	public long getStorage() {
		return storage;
	}
	public void setStorage(long storage) {
		this.storage = storage;
	}
	public long getLighting() {
		return lighting;
	}
	public void setLighting(long lighting) {
		this.lighting = lighting;
	}
	
	
	
}
