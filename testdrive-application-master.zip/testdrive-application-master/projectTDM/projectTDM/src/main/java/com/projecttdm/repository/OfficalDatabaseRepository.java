package com.projecttdm.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.projecttdm.entity.OfficalDatabase;


public interface OfficalDatabaseRepository extends JpaRepository<OfficalDatabase,Integer>{
	Optional<OfficalDatabase> findByZid(String id);
	
}
