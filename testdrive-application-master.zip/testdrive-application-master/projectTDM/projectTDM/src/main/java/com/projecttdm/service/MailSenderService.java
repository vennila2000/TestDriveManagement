package com.projecttdm.service;

public interface MailSenderService {
	public void sendMail(String to,String subject,String text);
}
