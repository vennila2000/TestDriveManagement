package com.projecttdm.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.projecttdm.entity.Feedback;
public interface FeedbackRepository extends JpaRepository<Feedback,Integer>{
	public Optional<Feedback> findByZid(String zid);
	public Optional<Feedback> findBycarid(int carid);
//	Optional<AboutCar> findByCarId(int id);
}
