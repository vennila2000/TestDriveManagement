package com.projecttdm.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.projecttdm.entity.CarDetails;
import com.projecttdm.entity.Image;
import com.projecttdm.repository.CarDetailsRepository;

@Service
public class CarDetailsService {
	 
	@Autowired ImageServiceInterface imageservice;
	@Autowired CarDetailsRepository carrepository;
	
	public ResponseEntity<?> addcar(CarDetails car, MultipartFile file) throws IOException {
		String fileName = file.getOriginalFilename();
        byte[] data = file.getBytes();
        car.setData(data);
        carrepository.save(car);
        return new ResponseEntity<String>("succcess raaaaaaaaa",HttpStatus.ACCEPTED);
	}
	public ResponseEntity<?> addNewCar(CarDetails cardetails){
		if(cardetails.getCarName().isEmpty()) {
			return new ResponseEntity<String>("CarName Cannot be null",HttpStatus.BAD_REQUEST);
		}
		else if(!cardetails.getCarName().matches("^[a-zA-Z]+$")) {
			return new ResponseEntity<String>("CarName Cannot have a number or a special character",HttpStatus.BAD_REQUEST);
		}
		else if(cardetails.getCarName().length() <= 2 || cardetails.getCarName().length() >=15) {
			return new ResponseEntity<String>("CarName should have more than 2 character and not more than 15 character",HttpStatus.BAD_REQUEST);
		}
		else if(cardetails.getEngine().length() <= 2 || cardetails.getEngine().length() >=15) {
			return new ResponseEntity<String>("Engine Details should have more than 2 character and not more than 15 character",HttpStatus.BAD_REQUEST);
		}
		else if(!cardetails.getEngine().matches("^[a-zA-Z0-9 ]+$")) {
			return new ResponseEntity<String>("Engine Details Cannot have a special character",HttpStatus.BAD_REQUEST);
		}
		else if(cardetails.getEngine().isEmpty()) {
			return new ResponseEntity<String>("Engine Cannot be null",HttpStatus.BAD_REQUEST);
		}
		else if(cardetails.getFuelType().isEmpty()) {
			return new ResponseEntity<String>("FuelType Cannot be null",HttpStatus.BAD_REQUEST);
		}
//		else if(cardetails.getFuelType().equalsIgnoreCase("petrol") && !cardetails.getFuelType().equalsIgnoreCase("diesel") ) {
//			return new ResponseEntity<String>("FuelType must be petrol or diesel",HttpStatus.BAD_REQUEST);
//		}
		else if(cardetails.getMaxPower().isEmpty()) {
			return new ResponseEntity<String>("Maxpower Cannot be null",HttpStatus.BAD_REQUEST);
		}
		else if(cardetails.getMaxPower().matches("^[^0-9].*")) {
			return new ResponseEntity<String>("MaxPower must start with a number",HttpStatus.BAD_REQUEST);
		}
		else if(!cardetails.getMaxPower().endsWith("rpm")) {
			return new ResponseEntity<String>("MaxPower must end with rpm",HttpStatus.BAD_REQUEST);
		}
		else if(!cardetails.getMaxPower().contains("@")) {
			return new ResponseEntity<String>("MaxPower must contain @",HttpStatus.BAD_REQUEST);
		}
		else if(cardetails.getMaxTorque().isEmpty()) {
			return new ResponseEntity<String>("MaxTorque Cannot be null",HttpStatus.BAD_REQUEST);
		}
		else if(cardetails.getMaxTorque().matches("^[^0-9].*")) {
			return new ResponseEntity<String>("MaxTorque must start with a number",HttpStatus.BAD_REQUEST);
		}
		else if(!cardetails.getMaxTorque().endsWith("rpm")) {
			return new ResponseEntity<String>("MaxTorque must end with rpm",HttpStatus.BAD_REQUEST);
		}
		else if(!cardetails.getMaxTorque().contains("@")) {
			return new ResponseEntity<String>("MaxTorque must contain @",HttpStatus.BAD_REQUEST);
		}
		else if(cardetails.getMileage().isEmpty()) {
			return new ResponseEntity<String>("Mileage cannot be null",HttpStatus.BAD_REQUEST);
		}
		else if(cardetails.getMileage().matches("^[^0-9].*")) {
			return new ResponseEntity<String>("Mileage must start with a number",HttpStatus.BAD_REQUEST);
		}
		else if(!cardetails.getMileage().endsWith("km/l")) {
			return new ResponseEntity<String>("Mileage must end with km/l",HttpStatus.BAD_REQUEST);
		}
		else if(cardetails.getTransmission().isEmpty()) {
			return new ResponseEntity<String>("Transmission cannot be null",HttpStatus.BAD_REQUEST);
		}
		else if(!cardetails.getTransmission().matches("^[^0-9]*[0-9][^0-9]*$")) {
			return new ResponseEntity<String>("Transmission must have atleast one number",HttpStatus.BAD_REQUEST);
		}
		else if(!cardetails.getTransmission().matches("^[a-zA-Z0-9]*$")) {
			return new ResponseEntity<String>("Transmission cannot have special character",HttpStatus.BAD_REQUEST);
		}
		else if(cardetails.getSeatingCapacity().isEmpty()) {
			return new ResponseEntity<String>("SeatingCapacity cannot be null",HttpStatus.BAD_REQUEST);
		}
		else if(!cardetails.getSeatingCapacity().matches("^[^0-9]*[0-9][^0-9]*$")) {
			return new ResponseEntity<String>("SeatingCapacity must have atleast one number",HttpStatus.BAD_REQUEST);
		}
		else if(!cardetails.getSeatingCapacity().matches("^[a-zA-Z0-9]*$")) {
			return new ResponseEntity<String>("SeatingCapacity cannot have special character",HttpStatus.BAD_REQUEST);
		}
		else if(!cardetails.getSeatingCapacity().matches("^[0-9]+$")) {
			return new ResponseEntity<String>("SeatingCapacity cannot have  character",HttpStatus.BAD_REQUEST);
		}
		else if(cardetails.getBootSpace().isEmpty()) {
			return new ResponseEntity<String>("BootSpace cannot be null",HttpStatus.BAD_REQUEST);
		}
		else if(cardetails.getBootSpace().matches("^[^0-9].*")) {
			return new ResponseEntity<String>("BootSpace must start with a number",HttpStatus.BAD_REQUEST);
		}
		else if(!cardetails.getBootSpace().endsWith("L")) {
			return new ResponseEntity<String>("BootSpace must end with L",HttpStatus.BAD_REQUEST);
		}
		else {
			carrepository.save(cardetails);
			return new ResponseEntity<String>("Successfully Added",HttpStatus.ACCEPTED);
		}
		
	}
}
