package com.projecttdm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.projecttdm.entity.CarDetails;
import com.projecttdm.entity.OfficalDatabase;
import com.projecttdm.repository.CarDetailsRepository;
import com.projecttdm.repository.OfficalDatabaseRepository;
import com.projecttdm.repository.TDRegisterationRepository;

@Service
public class TDRegisteration implements TDRegisterationService{
	
	@Autowired CarDetailsRepository cardetailsrepository;
	@Autowired TDRegisterationRepository tdregisterationrepository;
	@Autowired OfficalDatabaseRepository officaldatabaserepository;
	@Autowired MailSenderService mailsenderservice;
	@Override
	public ResponseEntity<?> testdriverregisteration(com.projecttdm.entity.TDRegisteration tdregisteration) {
		if(!cardetailsrepository.existsById(tdregisteration.getCarid())) {
			return new ResponseEntity<String>("car id invalid",HttpStatus.BAD_REQUEST);
		}
		else if(officaldatabaserepository.findByZid(tdregisteration.getZid()).isEmpty()) {
			return new ResponseEntity<String>("zid is invalid",HttpStatus.BAD_REQUEST);
		}
		else if(tdregisteration.getCarname() == null || tdregisteration.getCarname() == "") {
			return new ResponseEntity<String>("car name shouldn't be null",HttpStatus.BAD_REQUEST);
		}
		else if(cardetailsrepository.findByCarName(tdregisteration.getCarname()).isEmpty()) {
			return new ResponseEntity<String>("this is not the car for that id",HttpStatus.BAD_REQUEST);
		}
		else if(tdregisteration.getLocation() == null || tdregisteration.getLocation() == "") {
			return new ResponseEntity<String>("Location shouldn't be null",HttpStatus.BAD_REQUEST);
		}
		else if(tdregisteration.getSlottime() == null || tdregisteration.getSlottime() == "") {
			return new ResponseEntity<String>("Slottime shouldn't be null",HttpStatus.BAD_REQUEST);
		}
		else if(tdregisteration.getValidation() == null) {
			return new ResponseEntity<String>("Validation shouldn't be null",HttpStatus.BAD_REQUEST);
		}
		else {
			tdregisterationrepository.save(tdregisteration);
			Optional<OfficalDatabase> zid = officaldatabaserepository.findByZid(tdregisteration.getZid());
			String email = zid.get().getEmail();
			String subject = "TestDrive Registeration";
			String text = "Your TestDrive Location in "+tdregisteration.getLocation()+"  your timeslot is "+tdregisteration.getSlottime()+"  Don't Forget to Join in the event Thank You"; 
			mailsenderservice.sendMail(email, subject, text);
			return new ResponseEntity<String>("Successfully Registered",HttpStatus.OK);
			
		}
		
	}
	@Override
	public List<com.projecttdm.entity.TDRegisteration> getParticipant() {
		List<com.projecttdm.entity.TDRegisteration> allparticipant = tdregisterationrepository.findAll();
		return allparticipant;
	}
	@Override
	public ResponseEntity<?> getParticipantById(int carid) {
		if(cardetailsrepository.existsById(carid)) {
			Optional<com.projecttdm.entity.TDRegisteration> tdrbyid = Optional.of(tdregisterationrepository.findByCarid(carid).get());
			if(tdrbyid.isEmpty()) {
				return new ResponseEntity<String>("There is No participant for this car",HttpStatus.BAD_REQUEST);
			}
			else {
				return new ResponseEntity<Optional<com.projecttdm.entity.TDRegisteration>>(tdrbyid,HttpStatus.OK);
			}
		}
		else {
			return new ResponseEntity<String>("This car is not exist",HttpStatus.NOT_FOUND);
		}
	}
	
	public ResponseEntity<?> getParticipantByZid(String zid) {
		if(officaldatabaserepository.findByZid(zid).isPresent()) {
			if(tdregisterationrepository.findByZid(zid).isEmpty()) {
				return new ResponseEntity<String>("There is No participant in this zid",HttpStatus.BAD_REQUEST);
			}
			else {
				com.projecttdm.entity.TDRegisteration participantbyzid = tdregisterationrepository.findByZid(zid).get();
				return new ResponseEntity<com.projecttdm.entity.TDRegisteration>(participantbyzid,HttpStatus.OK);
			}
		}
		else {
			return new ResponseEntity<String>("This car is not exist",HttpStatus.NOT_FOUND);
		}
	}
}
