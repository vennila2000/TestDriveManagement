package com.projecttdm.service;

import org.springframework.http.ResponseEntity;

public interface FeedbackService {
	ResponseEntity<?> feedback(com.projecttdm.entity.Feedback feedbacks);
	ResponseEntity<?> getFeedbackById(int carid);
	ResponseEntity<?> getFeedback();
	ResponseEntity<?> getFeedbackByZid(String zid);

}
