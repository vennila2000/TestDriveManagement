package com.projecttdm.service;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.projecttdm.entity.Image;

public interface ImageServiceInterface {
	
	Image saveImage(String fileName, byte[] data);
	byte[] getImageById(Long id);
	public ResponseEntity<?> uploadImage(MultipartFile file);
	public ResponseEntity<?> getImage(Long id);
}
