package com.projecttdm.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.projecttdm.entity.CarDetails;
import com.projecttdm.entity.OfficalDatabase;

public interface CarDetailsRepository extends JpaRepository<CarDetails,Integer>{
	Optional<CarDetails> findByCarName(String carname);
}
