package com.projecttdm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.projecttdm.entity.CarDetails;
import com.projecttdm.repository.CarDetailsRepository;

@Service
public class Manufacture implements ManufactureService{
	@Autowired CarDetailsRepository cardetailsrepository;
	@Override
	public ResponseEntity<?> addcar(CarDetails cardetails) {
		cardetailsrepository.save(cardetails);
		return new ResponseEntity<String>("successfully Added",HttpStatus.OK);
	}
	
	public List<CarDetails> getCar(){
		return cardetailsrepository.findAll();
	}
	
	public ResponseEntity<?> getCarById(int id){
		if(cardetailsrepository.existsById(id)) {
			CarDetails cardetails = cardetailsrepository.findById(id).get();
			return new ResponseEntity<CarDetails>(cardetails,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<String>("This car is not exist",HttpStatus.NOT_FOUND);
		}
		
	}
	
}
